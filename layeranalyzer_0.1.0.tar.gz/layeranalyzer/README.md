# layeranalyzer
R package for causal and correlative time series analysis with hidden layers, using linear stochastic differential equations
