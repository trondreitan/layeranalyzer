## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----eval=FALSE---------------------------------------------------------------
# install.packages("https://github.com/trondreitan/layeranalyzer/raw/master/layeranalyzer_0.2.1.tar.gz",
# type="source",verbose=T)

## ----eval=FALSE---------------------------------------------------------------
# install_github(repo="trondreitan/layeranalyzer",dependencies=FALSE)

## ----eval=FALSE---------------------------------------------------------------
# install.packages("https://github.com/trondreitan/layeranalyzer/raw/master/layeranalyzer_0.2.1.tar.gz",
#    type="source",verbose=TRUE,build_vignettes=TRUE)

## ----eval=FALSE---------------------------------------------------------------
# install_github(repo="trondreitan/layeranalyzer",dependencies=FALSE,
#   build_vignettes=TRUE)

## ----out.width = "100%", echo = FALSE, fig.align="center", fig.cap="fig1"-----
dt=0.01
sdt=sqrt(dt)
T2=5
T1=2
t=seq(1,10,dt)
N=length(t)
x1=rep(0,N)
x2=rep(0,N)
for(i in 2:N)
{
  x2[i]=x2[i-1]-x2[i-1]*dt/T2+rnorm(1)*sdt
  x1[i]=x1[i-1]-(x1[i-1]-x2[i-1])*dt/T1
}
n=14
index=sort(sample(1:N,n))
y=x1[index]+0.25*rnorm(n)
par(cex=1.5)
plot(t,x1,type="l",lwd=3,xlab="time",
  ylab="process state and measurement values")
points(t[index],y,col="red",lwd=3)
for(i in 1:n)
  lines(c(t[index][i],t[index][i]),c(y[i],x1[index][i]),col="red",lwd=1)

## ----out.width = "100%", echo = FALSE, fig.align="center", fig.cap="test"-----
knitr::include_graphics("ou.png") 

## ----out.width = "100%", echo = FALSE, fig.align="center", fig.cap="test"-----
knitr::include_graphics("ou2.png") 

## ----out.width = "100%", echo = FALSE, fig.align="center", fig.cap="test"-----
knitr::include_graphics("ou_correlated.png") 

## ----out.width = "100%", echo = FALSE, fig.align="center", fig.cap="test"-----
knitr::include_graphics("causal.png") 

## ----out.width = "100%", echo = FALSE, fig.align="center", fig.cap="test"-----
knitr::include_graphics("causal_autocorr.png") 

## ----out.width = "100%", echo = FALSE, fig.align="center", fig.cap="test"-----
knitr::include_graphics("2layered.png") 

## ----out.width = "100%", echo = FALSE, fig.align="center", fig.cap="test"-----
knitr::include_graphics("3layers_2det.png") 

## ----out.width = "100%", echo = FALSE, fig.align="center", fig.cap="test"-----
knitr::include_graphics("hare_inf.png") 

## ----out.width = "100%", echo = FALSE, fig.align="center", fig.cap="test"-----
knitr::include_graphics("lynx_inf.png") 

## ----out.width = "100%", echo = FALSE, fig.align="center", fig.cap="test"-----
knitr::include_graphics("brach_ext.jpg") 

## ----out.width = "100%", echo = FALSE, fig.align="center", fig.cap="test"-----
knitr::include_graphics("hidden_sim.gif") 

