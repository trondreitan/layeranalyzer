## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----eval=FALSE---------------------------------------------------------------
#  install.packages("http://folk.uio.no/trondr/R/layeranalyzer_0.1.1.tar.gz",type="source",verbose=T)

## ----eval=FALSE---------------------------------------------------------------
#  install_github(repo="trondreitan/layeranalyzer",dependencies=FALSE)

## ----eval=FALSE---------------------------------------------------------------
#  install.packages("http://folk.uio.no/trondr/R/layeranalyzer_0.1.1.tar.gz",type="source",verbose=TRUE,
#     build_vignettes=TRUE)

## ----eval=FALSE---------------------------------------------------------------
#  install_github(repo="trondreitan/layeranalyzer",dependencies=FALSE,build_vignettes=TRUE)

## ----out.width = "100%", echo = FALSE, fig.align="center", fig.cap="test"-----
knitr::include_graphics("ou.png") 

## ----out.width = "100%", echo = FALSE, fig.align="center", fig.cap="test"-----
knitr::include_graphics("ou2.png") 

## ----out.width = "100%", echo = FALSE, fig.align="center", fig.cap="test"-----
knitr::include_graphics("ou_correlated.png") 

## ----out.width = "100%", echo = FALSE, fig.align="center", fig.cap="test"-----
knitr::include_graphics("causal.png") 

## ----out.width = "100%", echo = FALSE, fig.align="center", fig.cap="test"-----
knitr::include_graphics("causal_autocorr.png") 

## ----out.width = "100%", echo = FALSE, fig.align="center", fig.cap="test"-----
knitr::include_graphics("2layered.png") 

## ----out.width = "100%", echo = FALSE, fig.align="center", fig.cap="test"-----
knitr::include_graphics("3layer_2det.png") 

## ---- fig.show='hold'---------------------------------------------------------
plot(1:10)
plot(10:1)

## ---- echo=FALSE, results='asis'----------------------------------------------
knitr::kable(head(mtcars, 10))

