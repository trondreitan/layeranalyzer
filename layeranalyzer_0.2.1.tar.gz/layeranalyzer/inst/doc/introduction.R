## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----eval=FALSE---------------------------------------------------------------
#  install.packages("https://github.com/trondreitan/layeranalyzer/raw/master/layeranalyzer_0.2.1.tar.gz",
#  type="source",verbose=T)

## ----eval=FALSE---------------------------------------------------------------
#  install_github(repo="trondreitan/layeranalyzer",dependencies=FALSE)

## ----eval=FALSE---------------------------------------------------------------
#  install.packages("https://github.com/trondreitan/layeranalyzer/raw/master/layeranalyzer_0.2.1.tar.gz",
#     type="source",verbose=TRUE,build_vignettes=TRUE)

## ----eval=FALSE---------------------------------------------------------------
#  install_github(repo="trondreitan/layeranalyzer",dependencies=FALSE,
#    build_vignettes=TRUE)

## ----out.width = "100%", echo = FALSE, fig.align="center", fig.cap="test"-----
knitr::include_graphics("process_vs_timeseries.png") 

## ----out.width = "100%", echo = FALSE, fig.align="center", fig.cap="test"-----
knitr::include_graphics("ou.png") 

## ----out.width = "100%", echo = FALSE, fig.align="center", fig.cap="test"-----
knitr::include_graphics("ou2.png") 

## ----out.width = "100%", echo = FALSE, fig.align="center", fig.cap="test"-----
knitr::include_graphics("ou_correlated.png") 

## ----out.width = "100%", echo = FALSE, fig.align="center", fig.cap="test"-----
knitr::include_graphics("causal.png") 

## ----out.width = "100%", echo = FALSE, fig.align="center", fig.cap="test"-----
knitr::include_graphics("causal_autocorr.png") 

## ----out.width = "100%", echo = FALSE, fig.align="center", fig.cap="test"-----
knitr::include_graphics("2layered.png") 

## ----out.width = "100%", echo = FALSE, fig.align="center", fig.cap="test"-----
knitr::include_graphics("3layers_2det.png") 

## ----out.width = "100%", echo = FALSE, fig.align="center", fig.cap="test"-----
knitr::include_graphics("hare_inf.png") 

## ----out.width = "100%", echo = FALSE, fig.align="center", fig.cap="test"-----
knitr::include_graphics("lynx_inf.png") 

## ----out.width = "100%", echo = FALSE, fig.align="center", fig.cap="test"-----
knitr::include_graphics("brach_ext.jpg") 

## ----out.width = "100%", echo = FALSE, fig.align="center", fig.cap="test"-----
knitr::include_graphics("hidden_sim.gif") 

